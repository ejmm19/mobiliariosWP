# Elementor Pro

```bash
$ composer require yangm97/elementor-pro
```

This is just a mirror from the zip you would normally download from elementor.com, meaning that you still need a valid license to activate this plugin. No copyright infringement done.

This repository is a stop-gap solution until [elementor/elementor#4042](https://github.com/elementor/elementor/issues/4042) is addressed.

I will keep updating this repository on a best effort basis, but feel free to open a PR if I lag behind.
